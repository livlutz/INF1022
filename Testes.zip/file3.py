total = 0
for i in range(5):
	total = total + 2
print(total)