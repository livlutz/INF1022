a = 3
b = 7
a = a + b
print(a)