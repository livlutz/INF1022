num = 0
if num:
	print(num)
else:
	print(10)