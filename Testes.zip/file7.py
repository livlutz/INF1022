x = 3
y = 5
x = x * y
print(x)