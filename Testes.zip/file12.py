numero = 0
if numero:
	print(numero)