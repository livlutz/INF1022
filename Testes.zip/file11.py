contador = 1
for i in range(5):
	print(contador)
	contador = contador + 1