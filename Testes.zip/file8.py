resultado = 1
for i in range(3):
	resultado = resultado * 2
print(resultado)