resultado = 1
resultado = resultado * 5
resultado = resultado + 10
print(resultado)