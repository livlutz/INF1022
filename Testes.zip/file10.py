a = 3
b = 4
a = a + b
a = a * b
print(a)
print(b)