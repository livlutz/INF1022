x = 5
y = 10
print(x)
print(y)
print(15)