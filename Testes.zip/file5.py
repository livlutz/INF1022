n = 4
if n:
	print(n)